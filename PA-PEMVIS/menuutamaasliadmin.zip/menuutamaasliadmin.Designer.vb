﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class menuutamaasliadmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BunifuImageButton1 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.btnTransaksi = New Bunifu.Framework.UI.BunifuImageButton()
        Me.btnBook = New Bunifu.Framework.UI.BunifuImageButton()
        Me.btnUser = New Bunifu.Framework.UI.BunifuImageButton()
        Me.btnprofile = New Bunifu.Framework.UI.BunifuImageButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Button1 = New Bunifu.Framework.UI.BunifuImageButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Panel2.SuspendLayout()
        CType(Me.BunifuImageButton1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnTransaksi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnBook, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnprofile, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.Button1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(4, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Panel2.Controls.Add(Me.BunifuImageButton1)
        Me.Panel2.Controls.Add(Me.btnTransaksi)
        Me.Panel2.Controls.Add(Me.btnBook)
        Me.Panel2.Controls.Add(Me.btnUser)
        Me.Panel2.Controls.Add(Me.btnprofile)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(160, 648)
        Me.Panel2.TabIndex = 114
        '
        'BunifuImageButton1
        '
        Me.BunifuImageButton1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuImageButton1.Image = Global.PA_PEMVIS.My.Resources.Resources.book_shop
        Me.BunifuImageButton1.ImageActive = Nothing
        Me.BunifuImageButton1.Location = New System.Drawing.Point(37, 15)
        Me.BunifuImageButton1.Name = "BunifuImageButton1"
        Me.BunifuImageButton1.Size = New System.Drawing.Size(82, 82)
        Me.BunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.BunifuImageButton1.TabIndex = 133
        Me.BunifuImageButton1.TabStop = False
        Me.BunifuImageButton1.Zoom = 10
        '
        'btnTransaksi
        '
        Me.btnTransaksi.BackColor = System.Drawing.Color.Transparent
        Me.btnTransaksi.Image = Global.PA_PEMVIS.My.Resources.Resources.cash_machine
        Me.btnTransaksi.ImageActive = Nothing
        Me.btnTransaksi.Location = New System.Drawing.Point(41, 527)
        Me.btnTransaksi.Name = "btnTransaksi"
        Me.btnTransaksi.Size = New System.Drawing.Size(82, 95)
        Me.btnTransaksi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnTransaksi.TabIndex = 132
        Me.btnTransaksi.TabStop = False
        Me.btnTransaksi.Zoom = 10
        '
        'btnBook
        '
        Me.btnBook.BackColor = System.Drawing.Color.Transparent
        Me.btnBook.Image = Global.PA_PEMVIS.My.Resources.Resources.open_book1
        Me.btnBook.ImageActive = Nothing
        Me.btnBook.Location = New System.Drawing.Point(37, 392)
        Me.btnBook.Name = "btnBook"
        Me.btnBook.Size = New System.Drawing.Size(82, 95)
        Me.btnBook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnBook.TabIndex = 131
        Me.btnBook.TabStop = False
        Me.btnBook.Zoom = 10
        '
        'btnUser
        '
        Me.btnUser.BackColor = System.Drawing.Color.Transparent
        Me.btnUser.Image = Global.PA_PEMVIS.My.Resources.Resources.recruitment1
        Me.btnUser.ImageActive = Nothing
        Me.btnUser.Location = New System.Drawing.Point(37, 260)
        Me.btnUser.Name = "btnUser"
        Me.btnUser.Size = New System.Drawing.Size(82, 95)
        Me.btnUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnUser.TabIndex = 130
        Me.btnUser.TabStop = False
        Me.btnUser.Zoom = 10
        '
        'btnprofile
        '
        Me.btnprofile.BackColor = System.Drawing.Color.Transparent
        Me.btnprofile.Image = Global.PA_PEMVIS.My.Resources.Resources.user
        Me.btnprofile.ImageActive = Nothing
        Me.btnprofile.Location = New System.Drawing.Point(37, 138)
        Me.btnprofile.Name = "btnprofile"
        Me.btnprofile.Size = New System.Drawing.Size(82, 82)
        Me.btnprofile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btnprofile.TabIndex = 129
        Me.btnprofile.TabStop = False
        Me.btnprofile.Zoom = 10
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(4, Byte), Integer), CType(CType(74, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Button1)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(160, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(988, 70)
        Me.Panel3.TabIndex = 115
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.Image = Global.PA_PEMVIS.My.Resources.Resources.exit__1_
        Me.Button1.ImageActive = Nothing
        Me.Button1.Location = New System.Drawing.Point(921, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(55, 54)
        Me.Button1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Button1.TabIndex = 140
        Me.Button1.TabStop = False
        Me.Button1.Zoom = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Britannic Bold", 36.0!)
        Me.Label1.ForeColor = System.Drawing.Color.SandyBrown
        Me.Label1.Location = New System.Drawing.Point(383, 9)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(244, 53)
        Me.Label1.TabIndex = 119
        Me.Label1.Text = "Hi Admin !"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Britannic Bold", 36.0!)
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(480, 106)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(393, 53)
        Me.Label10.TabIndex = 118
        Me.Label10.Text = "SELAMAT DATANG"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Britannic Bold", 36.0!)
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(480, 358)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(384, 53)
        Me.Label2.TabIndex = 119
        Me.Label2.Text = "Di TOKO MANTAP"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Maroon
        Me.Label3.Location = New System.Drawing.Point(378, 450)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(613, 99)
        Me.Label3.TabIndex = 120
        Me.Label3.Text = "Selamat datang di toko Mantap disini kamu bisa " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "beli buku dengan banyak pilihan " &
    "dari kategori sampai" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " judul yang lengkap hanya ada di toko ini"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImage = Global.PA_PEMVIS.My.Resources.Resources.book_shop
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(600, 184)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(152, 156)
        Me.PictureBox3.TabIndex = 121
        Me.PictureBox3.TabStop = False
        '
        'menuutamaasliadmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(251, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1148, 648)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "menuutamaasliadmin"
        Me.Text = "SELAMAT DATANG "
        Me.Panel2.ResumeLayout(False)
        CType(Me.BunifuImageButton1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnTransaksi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnBook, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnprofile, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.Button1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents btnprofile As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents btnUser As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents btnBook As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents btnTransaksi As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents BunifuImageButton1 As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents Button1 As Bunifu.Framework.UI.BunifuImageButton
End Class
